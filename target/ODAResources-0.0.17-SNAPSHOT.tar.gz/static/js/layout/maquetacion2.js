/**
 *  @file        : maquetacion2.js
 *
 *  @description : JS de maquetación para el doc maquetacion2
 *  @license     : baratz
 *  @copyright   : 2019
 *
 *  @author      : http://www.baratz.es/
 *  @date        : 2021-06-18
 *
 *  @validate    : https://jshint.com/
 */
// jshint jquery :true, esversion:10
/* globals Baratz,BaratzContextPath*/

console.log("[maquetacion2.js] CARGA");





