/**
 *  @file        : maquetacion3.js
 *
 *  @description : JS de maquetación para el doc maquetacion3
 *  @license     : baratz
 *  @copyright   : 2019
 *
 *  @author      : http://www.baratz.es/
 *  @date        : 2021-06-18
 *
 *  @validate    : https://jshint.com/
 */
// jshint jquery :true, esversion:10
/* globals Baratz,BaratzContextPath*/

console.log("[maquetacion3.js] CARGA");


/* new Sortable(example1, {
  animation: 150,
  ghostClass: 'blue-background-class'
});

// Grid demo
new Sortable(gridDemo, {
	animation: 150,
	ghostClass: 'blue-background-class'
});

new Sortable(multiDragDemo, {
  multiDrag: true, // Enable multi-drag
  selectedClass: 'selected', // The class applied to the selected items
  fallbackTolerance: 3, // So that we can select items on mobile
  ghostClass: 'blue-background-class',
  animation: 150
}); */